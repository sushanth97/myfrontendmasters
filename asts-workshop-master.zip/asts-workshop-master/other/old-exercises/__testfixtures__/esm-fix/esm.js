export {foo}

function foo() {}
