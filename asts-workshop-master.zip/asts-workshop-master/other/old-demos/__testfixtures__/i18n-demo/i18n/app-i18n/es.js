module.exports = {
  title: 'Hola Mundo',
  subtitle: '¡Es un lindo día!',
  greeting: '¡Hola {name}!',
}
