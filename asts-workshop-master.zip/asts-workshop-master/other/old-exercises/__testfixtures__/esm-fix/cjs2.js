module.exports = {
  baz: {
    buzz: 32,
  },
  foobar() {},
}
