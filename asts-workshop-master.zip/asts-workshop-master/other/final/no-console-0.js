module.exports = {
  // you're going to need context :)
  // eslint-disable-next-line no-unused-vars
  create(context) {
    return {}
  },
}
