module.exports = {
  testEnvironment: 'node',
}
