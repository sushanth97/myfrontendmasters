module.exports = {
  title: 'Hello world',
  subtitle: 'It is a nice day!',
  greeting: 'Hi there {name}!',
}
