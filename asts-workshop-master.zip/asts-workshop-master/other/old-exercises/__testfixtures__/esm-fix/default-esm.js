export default myFunction

function myFunction() {}
