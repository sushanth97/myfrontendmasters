const foo = 'hi'
const bar = 'hey'
const baz = 'hello'

export {foo, bar}
export default baz
