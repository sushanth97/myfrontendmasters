module.exports = {
  testEnvironment: 'node',
  roots: ['./exercises'],
}
